<h1>Create New Category</h1>

<form method="post" action="/categories/create">
    Category name: <input type="text" name="CategoryName" />
    <br/>
    <input type="submit" value="Create">
    <a href="/categories">Cancel</a>
</form>
