<h1>Register Form</h1>
<form method="post" action="/account/register">
    Username: <input type="text" name="username" />
    <br/>
    Password: <input type="password" name="password" />
    <br/>
    <input type="submit" value="Register">
    <br/>
    <a href="login">[Go Login]</a>
</form>