<h1>Login Form</h1>
<form method="post" action="/account/login">
    Username: <input type="text" name="username" />
    <br/>
    Password: <input type="password" name="password" />
    <br/>
    <input type="submit" value="Login">
    <br/>
    <a href="register">[Go Register]</a>
</form>