<footer>(c) The Food Store 2015</footer>
</body>

</html>
