<?php


class CartModel extends BaseModel
{

}