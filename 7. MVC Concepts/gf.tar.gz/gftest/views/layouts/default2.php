<html>
    <head><?= $this->title; ?></head>
    <body>
         <?=$this->getLayoutData('body2');?> 
        <hr>
          <?=$this->getLayoutData('body');?>  
         
    </body>
</html>