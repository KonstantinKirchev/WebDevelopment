<html>
    <head><?= $this->title; ?></head>
    <body>
          <?=$this->getLayoutData('body');?>  
         <?=$this->getLayoutData('body2');?>  
    </body>
</html>