<?php
$cnf['getLatestComments']='post/getComments';
return $cnf;