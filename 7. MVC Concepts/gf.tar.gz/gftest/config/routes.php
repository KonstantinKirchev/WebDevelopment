<?php
$cnf['admin']['namespace']='Controllers\Admin';
$cnf['admin']['controllers']['index']['to']='test';
$cnf['admin']['controllers']['index']['methods']['new']['to']='_new';
$cnf['*']['namespace']='Controllers';

return $cnf;