<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Index
 *
 * @author gatakka
 */
namespace Controllers\Admin;
class Index {
    public function index2(){
        echo 'basi kefa';
    }
}

