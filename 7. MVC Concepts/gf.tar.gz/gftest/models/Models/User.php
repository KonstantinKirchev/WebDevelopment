<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author gatakka
 */
namespace Test\Models\Test2;
class User {
    //put your code here
}

?>
