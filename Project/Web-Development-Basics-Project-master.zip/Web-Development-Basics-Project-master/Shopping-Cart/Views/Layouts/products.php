<html>
<head>
    <meta charset="UTF-8">
    <title>All Products</title>
    <?= $this->getLayoutData('meta') ?>
</head>
<body>
<?= $this->getLayoutData('header'); ?>
<div class="container siteContainer">
    <?= $this->getLayoutData('body'); ?>
</div>
<?= $this->getLayoutData('footer'); ?>
<?php
?>
</body>
</html>