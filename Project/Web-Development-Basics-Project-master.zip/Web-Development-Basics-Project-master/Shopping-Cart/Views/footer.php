<footer class="container-fluid navbar-fixed-bottom">
    <div class="col-sm-4">Author: Spas Vutov</div>
    <div class="col-sm-4">Project's <a href="https://github.com/Vutov/Web-Development-Basics-Project">Github</a></div>
    <div class="col-sm-4">Powered by FTS-Framework &copy;</div>
</footer>