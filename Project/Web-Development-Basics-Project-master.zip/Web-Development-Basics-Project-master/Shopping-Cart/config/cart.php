<?php
$cnf['initialCash'] = 10000;
return $cnf;