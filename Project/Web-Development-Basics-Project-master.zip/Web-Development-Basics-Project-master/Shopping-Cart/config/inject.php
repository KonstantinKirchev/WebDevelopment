<?php
$cnf['Validator'] = 'FTS\Validator';
$cnf['SimpleDB'] = 'FTS\DB\SimpleDB';

return $cnf;