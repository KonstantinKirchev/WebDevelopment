<?php
/**
 * Errors to be displayed with message
 */

$cnf[400] = 'message';
$cnf[401] = 'Unauthorized!';
$cnf[404] = 'Not Found!';

return $cnf;