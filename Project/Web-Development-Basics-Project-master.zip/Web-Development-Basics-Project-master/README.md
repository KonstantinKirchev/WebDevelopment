# Web-Development-Basics-Project
<h2>FTS Framework DONE<br /></h2>
<p>
Progress: <br />
Default routing system Done <br />
Custom routing system Done <br />
Areas Done <br />
Strongly typed views Done <br />
POST request actions using Binding Models Done <br />
ViewHelpers for Forms, Ajax submitted Forms, CSRF Token Done <br />
Form ViewHelper Done <br />
Out of the box escaping the html chars unless stated otherwise Done <br />
Data annotations Done <br />
Overriding default route config with annotations Done <br />
Dependency injection configuration (config file or annotation) Done <br />
User roles and config/annotation for them Done <br />
Upload files ViewHelper Done <br />
Help page that scans all routes  Done <br />
</p>
<h2>Project: <br /></h2>
Required functionalities: DONE <br />
User registration / login and user profiles. Done <br />
User roles (user, administrator editor) Done <br />
Initial cash for users Done <br />
Product categories Done <br />
Listing products in categories Done <br />
Add to cart functionality Done <br />
Promotions for certain time interval Done <br />
Quantity visibility Done <br />
Checkout the cart  Done <br />
View cart Done <br />
Users can sell bought products Done <br />
Editors can add/delete product categories  Done <br />
Editors can add/delete products Done <br />
Editors can move products between categories Done <br />
Editors can change quantities Done <br />
Editors can reorder products Done <br />
Administrators have full access on products, categories, users and their possessions  Done <br />
Bonus functionalities:
Managing the cart  Done <br />
Users can sell products Done <br />
Users can make comments on products (review)  Done <br />
Administrators: ban users  Not started <br />
Administrators: ban IP’s  Not started <br />