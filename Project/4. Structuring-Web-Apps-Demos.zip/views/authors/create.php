<h1>Create New Author</h1>

<form method="post" action="/authors/create">
    Author name: <input type="text" name="name" />
    <br/>
    <input type="submit" value="Create">
    <a href="/authors">Cancel</a>
</form>
