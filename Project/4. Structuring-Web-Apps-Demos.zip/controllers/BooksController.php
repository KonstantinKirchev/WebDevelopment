<?php

class BooksController extends BaseController {
}
