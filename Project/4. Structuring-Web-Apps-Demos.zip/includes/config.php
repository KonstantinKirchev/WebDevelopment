<?php

define('DEFAULT_CONTROLLER', 'home');
define('DEFAULT_ACTION', 'index');
define('DEFAULT_VIEW', 'index');
define('DEFAULT_LAYOUT', 'default');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mvc');

define('INFO_MESSAGES_SESSION_KEY', 'infoMessages');
define('ERROR_MESSAGES_SESSION_KEY', 'errorMessages');
