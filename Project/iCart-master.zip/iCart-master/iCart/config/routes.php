<?php
$cnf['admin']['namespace'] = 'Areas\Admin\Controllers';
$cnf['*']['namespace'] = 'Controllers';
return $cnf;