<?php
// example route
$cnf['getLatestComments'] = 'post/getComments';

return $cnf;