<?php

$cnf = array(
    "Admin",
    "Editor",
    "Authorize"
);

return $cnf;