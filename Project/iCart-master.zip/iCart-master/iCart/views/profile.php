<section class="bg-1">
    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <form action="" method="post" class="form col-lg-12 center-block">
                <div class="form-group">
                    <input name="password" type="password" class="form-control input-lg" placeholder="Old Password">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control input-lg" placeholder="New Password">
                </div>
                <div class="form-group">
                    <input name="confirmPassword" type="password" class="form-control input-lg"
                           placeholder="Confirm Password">
                </div>
                <div class="form-group">
                    <div class="col-lg-6">
                        <input type="submit" class="btn btn-primary btn-lg btn-block" value="Send"/>
                    </div>
                    <div class="col-lg-6">
                        <a href="/" class="btn btn-default btn-lg btn-block col-lg-6">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>