<section class="bg-1">
    <div class="col-sm-6 col-sm-offset-3 text-center">
        <h2 style="padding:20px;background-color:rgba(5,5,5,.8)">Laptops</h2>
    </div>
</section>

<div class="continer bg-4">
    <div class="row">

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div><img src="//placehold.it/450X250/565656/eee" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Laptop</p>

                    <p>Model</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/ffcc33/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Laptop</p>

                    <p>Model</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/f16251/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Laptop</p>

                    <p>Model</p>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="divider"></div>

<section class="bg-2">
    <div class="col-sm-6 col-sm-offset-3 text-center">
        <h2 style="padding:20px;background-color:rgba(5,5,5,.8)">Tablets</h2>
    </div>
</section>

<div class="continer bg-4">
    <div class="row">

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div><img src="//placehold.it/450X250/565656/eee" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Tablet</p>

                    <p>Model</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/ffcc33/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Tablet</p>

                    <p>Model</p>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/f16251/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Tablet</p>

                    <p>Model</p>
                </div>
            </div>
            <!--/panel-->
        </div>
        <!--/col-->

    </div>
    <!--/row-->
</div><!--/container-->

<div class="divider"></div>

<section class="bg-3">
    <div class="col-sm-6 col-sm-offset-3 text-center">
        <h2 style="padding:20px;background-color:rgba(5,5,5,.8)">Smartphones</h2>
    </div>
</section>

<div class="continer bg-4">
    <div class="row">

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div><img src="//placehold.it/450X250/565656/eee" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Smartphone</p>

                    <p>Model</p>
                </div>
            </div>
            <!--/panel-->
        </div>
        <!--/col-->

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/ffcc33/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Smartphone</p>

                    <p>Model</p>
                </div>
            </div>
            <!--/panel-->
        </div>
        <!--/col-->

        <div class="col-lg-4 col-sm-6">
            <div class="panel panel-default">
                <div class="panel-thumbnail"><img src="//placehold.it/450X250/f16251/444" class="img-responsive"></div>
                <div class="panel-body">
                    <p class="lead">Smartphone</p>

                    <p>Model</p>
                </div>
            </div>
            <!--/panel-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div><!--/container-->

