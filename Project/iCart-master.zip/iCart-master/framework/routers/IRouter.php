<?php

namespace Framework\Routers;

interface IRouter
{
    public function getUri();

    public function getPost();
}