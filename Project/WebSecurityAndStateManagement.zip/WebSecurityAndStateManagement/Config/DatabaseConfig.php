<?php

namespace Config;


class DatabaseConfig
{
    const DB_DRIVER = 'mysql';
    const DB_HOST = 'localhost';
    const DB_USER = 'root';
    const DB_PASS = '';
    const DB_NAME = 'application';
    const DB_INSTANCE = 'app';
}