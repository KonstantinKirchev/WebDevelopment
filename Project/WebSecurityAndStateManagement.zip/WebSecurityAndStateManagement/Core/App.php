<?php
/**
 * Created by PhpStorm.
 * User: Konstantin
 * Date: 23.9.2015 �.
 * Time: 21:26
 */

namespace Core;


class App
{
    private $db;
    private $user = null;

    public function _construct(Database $db){
        $this->db = $db;
    }

    public function isLogged(){
        return isset($_SESSION['id']);
    }
}