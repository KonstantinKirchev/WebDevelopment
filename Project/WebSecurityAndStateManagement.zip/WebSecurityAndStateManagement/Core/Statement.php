<?php
/**
 * Created by PhpStorm.
 * User: Konstantin
 * Date: 23.9.2015 �.
 * Time: 21:08
 */

namespace Core;


class Statement
{
    public function fetch($fetchStyle = \PDO::FETCH_ASSOC)
    {
        return $this->stmt->fetch($fetchStyle);
    }

    public  function fetchAll($fetchStyle = \PDO::FETCH_ASSOC)
    {
        return $this->stmt->fetchAll($fetchStyle);
    }

    public function bindParam($parameter, &$variable, $dataType = \PDO::PARAM_STMT, $length)
    {
        return $this->stmt->bindParam($parameter, $variable, $dataType, $length);
    }
}