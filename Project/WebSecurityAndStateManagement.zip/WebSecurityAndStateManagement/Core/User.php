<?php
/**
 * Created by PhpStorm.
 * User: Konstantin
 * Date: 23.9.2015 �.
 * Time: 21:22
 */

namespace Core;


class User
{
    private $id;
    private $user;
    private $pass;
    private $gold;
    private $food;

    const GOLD_DEFAULT = 1500;
    const FOOD_DEFAULT = 1500;

    public function _construct($user, $pass, $id = null, $gold = null, $food = null)
    {
        $this->setId($id)
            ->setUsername($user)
            ->setPass($pass)
            ->setGold($gold)
            ->setFood($food);
    }
}