<form action="" method="post">
    <input type="text" name="username">
    <input type="password" name="password">
    <input type="submit" value="Register">
</form>
<?php
/**
 * Created by PhpStorm.
 * User: Konstantin
 * Date: 23.9.2015 �.
 * Time: 22:29
 */