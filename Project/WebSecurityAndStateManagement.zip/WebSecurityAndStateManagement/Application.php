<?php

/**
 * Created by PhpStorm.
 * User: Konstantin
 * Date: 23.9.2015 �.
 * Time: 22:17
 */
class Application
{
    public function userExists($username)
    {
        $result = $this->db->prepare("SELECT id FROM users WHERE username = ?");
        $result->execute([$username]);

        return $result->rowCount() > 0;
    }

    public function register($username, $password)
    {
        if($this->userExists($username)){
            throw new \Exception("User already registered");
        }

        $result = $this->db->prepare("
            INSERT INTO users (username, password, gold, food)
            VALUES (?, ?, ?, ?);
        ");

        $result->execute(
            [
                $username,
                password_hash($password, PASSWORD_DEFAULT),
                \Core\User::GOLD_DEFAULT,
                \Core\User::FOOD_DEFAULT
            ]
        );

        if($result->rowCount() > 0){
            $userId = $this->db->lastId();

            $this->db->query("
                INSERT INTO user_buildings (user_id, building_id, level_id)
                SELECT $userId, id, 0 FROM buildings
            ");

            return true;
        }

        throw new \Exception('Cannot register user');
    }
}