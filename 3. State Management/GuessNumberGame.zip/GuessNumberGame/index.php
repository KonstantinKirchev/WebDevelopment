<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
<h1>Please enter your name:</h1>
<form method="post">
    Username: <input type="text" name="user" />
    <input type="submit" value="Start Game" />
</form>
</body>
</html>

<?php
if (isset($_POST['user']) && $_POST['user'] != "") {
    $username = $_POST['user'];
    session_start();
    $_SESSION['user'] = $username;
    $_SESSION['secretNumber'] = rand(1,100);
    $_SESSION['counter'] = 1;
    if($_SESSION['bestScore'] == null){
        $_SESSION['bestScore'] = PHP_INT_MAX;
    }
    header('Location: play.php');
    die;
}
?>