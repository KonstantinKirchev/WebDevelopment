<!DOCTYPE html>
<html>
<head>
    <title>Play</title>
    <link rel="stylesheet" href="styles.css" />
</head>
<body>
<h1>Welcome
    <?php
    session_start();
    echo htmlspecialchars($_SESSION['user']); ?>
    . Guess the secret number:</h1>
<form method="post">
    Please enter a number in the range [1..100]: <input type="text" name="number" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>

<?php
$secretNumber = $_SESSION['secretNumber'];
$user = $_SESSION['user'];

if (isset($_POST['number'])) {
    $number = $_POST['number'];

    if($number == $secretNumber){
        if($_SESSION['counter'] < $_SESSION['bestScore']){
            $_SESSION['bestScore'] = $_SESSION['counter'];
        }
        echo "Congratulations, $user. You have tried {$_SESSION['counter']} times. The best score is {$_SESSION['bestScore']}.";
        unset($_SESSION['secretNumber']);
        unset($_SESSION['user']);?>
    <form method="post" action="index.php">
        <input type="submit" name="play" value="Play Again" />
    </form>
    <?php
    }
    else if($number < 1 || $number > 100){
        $_SESSION['counter']++;
        echo 'Invalid Number';
    }
    else if($number < $secretNumber && $number >= 1 && $number <= 100){
        $_SESSION['counter']++;
        echo 'Up';
    }
    else if($number > $secretNumber && $number >= 1 && $number <= 100){
        $_SESSION['counter']++;
        echo 'Down';
    }
}
?>