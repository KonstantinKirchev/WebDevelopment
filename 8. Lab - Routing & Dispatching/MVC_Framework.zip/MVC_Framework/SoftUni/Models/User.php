<?php

namespace SoftUni\Models;


use SoftUni\Core\Database;
use SoftUni\Core\Statement;

class User
{
    public function register($username, $password)
    {
        $db = Database::getInstance('app');

        if($this->exists($username)){
            throw new \Exception("User already registered");
        }

        $result = $db->prepare("
        INSERT INTO users (username, password, gold, food)
        VALUES (?, ?, ?, ?);
        ");

        $result->execute(
          [
              $username,
              password_hash($password, PASSWORD_DEFAULT),
              self::GOLD_DEFAULT,
              self::FOOD_DEFAULT
          ]
        );

        if($result->rowCount() > 0){
            $userId = $db->lastId();

            $db->query("
                INSERT INTO user_buildings (user_id, building_id, level_id)
                SELECT $userId, id, 0 FROM buildings
            ");

            return true;
        }

        throw new \Exception('Cannot register user');
    }
}