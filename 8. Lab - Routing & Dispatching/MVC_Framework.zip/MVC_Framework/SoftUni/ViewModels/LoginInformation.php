<?php

namespace SoftUni\ViewModels;


class LoginInformation
{
    public $error = false;
    public $success = false;
}