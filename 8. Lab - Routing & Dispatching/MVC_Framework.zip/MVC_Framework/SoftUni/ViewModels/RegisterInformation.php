<?php

namespace SoftUni\ViewModels;


class RegisterInformation
{
    public $error = false;
    public $success = false;
}