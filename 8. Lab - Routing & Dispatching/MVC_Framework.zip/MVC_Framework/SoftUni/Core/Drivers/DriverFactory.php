<?php

namespace SoftUni\Core\Drivers;

include 'DriverAbstract.php';
include 'MySQLDriver.php';

class DriverFactory
{
    public static function create($driver, $user, $pass, $dbName, $host) {
        $driver = new MySQLDriver($user, $pass, $dbName, $host);
        return $driver;
    }
}