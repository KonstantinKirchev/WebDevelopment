<?php

namespace SoftUni\Controllers;


abstract class Controller
{
    public function is_user_logged_in()
    {

    }
}