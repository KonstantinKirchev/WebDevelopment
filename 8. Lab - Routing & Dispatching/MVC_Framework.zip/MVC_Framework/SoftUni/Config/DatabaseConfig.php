<?php

namespace SoftUni\Config;


class DatabaseConfig
{
    const DB_DRIVER = 'mysql';
    const DB_HOST = 'localhost:8001';
    const DB_USER = 'root';
    const DB_PASS = '';
    const DB_NAME = 'application';
    const DB_INSTANCE = 'app';
}